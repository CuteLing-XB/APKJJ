package com.example.liquidglass;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;

public class GlassButton extends TextView {

    private final Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float highlightX = .5f;
    private boolean held = false;
    private OnPressStateChangedListener listener;

    public interface OnPressStateChangedListener {
        void onChanged(boolean pressed);
    }

    public GlassButton(Context context) {
        super(context);
        init();
    }

    public GlassButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public GlassButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setGravity(android.view.Gravity.CENTER);
        setClickable(true);
        setFocusable(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        GradientDrawable background = new GradientDrawable();
        background.setColor(0x3FFFFFFF);
        background.setCornerRadius(dp(28f));
        setBackground(background);

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            setElevation(dp(8f));
        }

        setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    held = true;
                    highlightX = normalizeX(event.getX());
                    animate().cancel();
                    animate()
                            .scaleX(.965f)
                            .scaleY(.965f)
                            .setDuration(90L)
                            .start();
                    if (listener != null) listener.onChanged(true);
                    invalidate();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    highlightX = normalizeX(event.getX());
                    invalidate();
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    held = false;
                    animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(240L)
                            .setInterpolator(new OvershootInterpolator(1.2f))
                            .start();
                    if (listener != null) listener.onChanged(false);
                    invalidate();
                    return true;
            }
            return true;
        });
    }

    private float normalizeX(float x) {
        return Math.max(0f, Math.min(1f, x / Math.max(1f, getWidth())));
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    public void setOnPressStateChangedListener(OnPressStateChangedListener l) {
        listener = l;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        // Finger-following specular strip; stronger while held.
        final float spread = held ? dp(125f) : dp(88f);

        shine.setStyle(Paint.Style.FILL);
        shine.setShader(new LinearGradient(
                highlightX * w - spread, 0f,
                highlightX * w + spread, h,
                new int[]{
                        0x00FFFFFF,
                        held ? 0xD8FFFFFF : 0x70FFFFFF,
                        0x00FFFFFF
                },
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(
                dp(2f), dp(2f),
                w - dp(2f), h - dp(2f),
                dp(27f), dp(27f),
                shine
        );

        // Thin glass rim.
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(dp(1.1f));
        edge.setShader(new LinearGradient(
                highlightX * w - dp(110f), 0f,
                highlightX * w + dp(110f), h,
                new int[]{0x00FFFFFF, 0xE8FFFFFF, 0x00FFFFFF},
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(
                dp(1f), dp(1f),
                w - dp(1f), h - dp(1f),
                dp(28f), dp(28f),
                edge
        );

        // Top glossy lens band.
        shine.setShader(new LinearGradient(
                0f, 0f,
                0f, h * .55f,
                0x58FFFFFF, 0x00FFFFFF,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(
                dp(3f), dp(2f),
                w - dp(3f), h * .56f,
                dp(25f), dp(25f),
                shine
        );

        shine.setShader(null);
        edge.setShader(null);
    }
}
