package com.example.liquidglass;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ImageView imageA;
    private ImageView imageB;
    private TextView counter;
    private boolean showingA = true;
    private int page = 0;

    private final int[] backgrounds = {
            R.drawable.bg_01,
            R.drawable.bg_02
    };

    private final Runnable autoSwitch = new Runnable() {
        @Override
        public void run() {
            switchBackground();
            handler.postDelayed(this, 5000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestFullscreen();
        setContentView(R.layout.activity_main);

        imageA = findViewById(R.id.imageA);
        imageB = findViewById(R.id.imageB);
        counter = findViewById(R.id.counter);

        if (imageA != null) {
            imageA.setImageResource(backgrounds[0]);
        }
        if (imageB != null) {
            imageB.setImageResource(backgrounds[1]);
            imageB.setAlpha(0f);
        }

        updateCounter();
    }

    private void requestFullscreen() {
        Window window = getWindow();
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }
    }

    private void switchBackground() {
        if (imageA == null || imageB == null) return;

        final ImageView front = showingA ? imageB : imageA;
        final ImageView back = showingA ? imageA : imageB;

        page = (page + 1) % backgrounds.length;
        front.setImageResource(backgrounds[page]);
        front.setScaleX(1.035f);
        front.setScaleY(1.035f);
        front.setAlpha(0f);

        // The overlap is intentional: both images stay visible during the transition.
        front.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(1050L)
                .start();

        back.animate()
                .alpha(0f)
                .scaleX(0.99f)
                .scaleY(0.99f)
                .setDuration(1050L)
                .start();

        showingA = !showingA;
        updateCounter();
    }

    private void updateCounter() {
        if (counter != null) {
            counter.setText(String.format("%02d / %02d", page + 1, backgrounds.length));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(autoSwitch);
        handler.postDelayed(autoSwitch, 5000L);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(autoSwitch);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
