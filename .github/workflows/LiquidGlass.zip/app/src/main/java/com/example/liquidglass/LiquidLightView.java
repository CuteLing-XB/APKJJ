package com.example.liquidglass;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/**
 * Lightweight, device-friendly liquid-light overlay.
 * It simulates refraction/lensing with translucent moving light bands
 * instead of relying on newer blur APIs that can break on older devices.
 */
public class LiquidLightView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float phase = 0f;

    public LiquidLightView(Context context) {
        super(context);
        init();
    }

    public LiquidLightView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public LiquidLightView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setClickable(false);
        setFocusable(false);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        phase += 0.0055f;
        if (phase > 6.283185f) {
            phase -= 6.283185f;
        }

        float x = (float) ((Math.sin(phase) * 0.5f + 0.5f) * (w * 1.5f) - w * 0.25f);

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(
                x, 0f,
                x + Math.max(220f, w * 0.38f), h,
                new int[]{0x00FFFFFF, 0x35FFFFFF, 0x00FFFFFF},
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRect(0f, 0f, w, h, paint);

        // Soft top light gives the glass a lens-like rounded impression.
        paint.setShader(new LinearGradient(
                0f, 0f,
                0f, Math.max(1f, h * 0.55f),
                new int[]{0x2CFFFFFF, 0x06FFFFFF, 0x00FFFFFF},
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRect(0f, 0f, w, h, paint);

        paint.setShader(null);
        postInvalidateOnAnimation();
    }
}
