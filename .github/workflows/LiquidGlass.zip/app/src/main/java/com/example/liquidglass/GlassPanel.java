package com.example.liquidglass;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

public class GlassPanel extends FrameLayout {

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GlassPanel(Context context) {
        super(context);
        init();
    }

    public GlassPanel(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public GlassPanel(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setWillNotDraw(false);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        GradientDrawable background = new GradientDrawable();
        background.setColor(0x4DFFFFFF);
        background.setCornerRadius(dp(30f));
        setBackground(background);

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            setElevation(dp(10f));
        }
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        // Transparent material: background remains visible through the panel.
        fill.setStyle(Paint.Style.FILL);
        fill.setShader(new LinearGradient(
                0f, 0f, w, h,
                0x46FFFFFF, 0x16FFFFFF,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(
                dp(1f), dp(1f),
                w - dp(1f), h - dp(1f),
                dp(30f), dp(30f),
                fill
        );

        // Bright upper rim / specular edge.
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(dp(1.2f));
        edge.setShader(new LinearGradient(
                0f, 0f, 0f, Math.max(1f, h * .42f),
                0xE6FFFFFF, 0x10FFFFFF,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(
                dp(1f), dp(1f),
                w - dp(1f), h - dp(1f),
                dp(30f), dp(30f),
                edge
        );

        // Lower edge gives a subtle curved-lens depth.
        edge.setShader(new LinearGradient(
                0f, h * .60f, 0f, h,
                0x08FFFFFF, 0x6AFFFFFF,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(
                dp(2f), dp(2f),
                w - dp(2f), h - dp(2f),
                dp(29f), dp(29f),
                edge
        );

        fill.setShader(null);
        edge.setShader(null);
    }
}
