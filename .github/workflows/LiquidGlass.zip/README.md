# Liquid Glass 自动换图 + 穿透高光

这是完整 Android 工程。

## 已加入
- 你提供的两张图片：`bg_01.jpg`、`bg_02.jpg`
- 每 5 秒自动切换
- 两张图片同时存在于切换过程，形成叠影/交叉淡化
- 切换时轻微缩放，增加柔和景深感
- 透明玻璃面板，背景可穿透看到
- 玻璃边缘高光
- 动态扫光
- 按住按钮：高光增强并跟随手指
- 松开：柔性回弹
- Android 6.0+ 兼容
- 不依赖 AppCompat / 第三方 UI 库
- 不使用高风险的新式 Blur API，避免部分机型启动或渲染崩溃
- GitHub Actions 云端打包

## GitHub 打包
1. 将整个工程上传到 GitHub 仓库根目录。
2. 确认 `.github/workflows/build.yml` 存在。
3. 打开 Actions。
4. 点击 `Build Liquid Glass APK`。
5. 点击 `Run workflow`。
6. 完成后，在 Artifacts 下载 `LiquidGlass-AutoSwitch-APK`。

## 修改
背景图放在：
`app/src/main/res/drawable-nodpi/`

自动切换时间在：
`MainActivity.java`

当前是：
`5000L` = 5 秒。

这个工程是 Android 上的 Liquid Glass 视觉模拟，不是 Apple 私有 UIGlassEffect 的移植。
