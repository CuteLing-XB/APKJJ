package com.example.liquidglass;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.FrameLayout;

public class GlassPanel extends FrameLayout {
    private final Paint glass = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GlassPanel(Context context) {
        super(context);
        setWillNotDraw(false);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setBackground(new GradientDrawable() {{
            setColor(0x7AFFFFFF);
            setCornerRadius(30);
        }});
        setElevation(18);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float r = 30f;
        glass.setStyle(Paint.Style.STROKE);
        glass.setStrokeWidth(1.4f);
        glass.setShader(new LinearGradient(0, 0, getWidth(), getHeight(),
                0xDFFFFFFF, 0x45FFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(0.7f, 0.7f, getWidth()-0.7f, getHeight()-0.7f, r, r, glass);

        edge.setShader(new LinearGradient(0, 0, 0, getHeight() * .32f,
                0xBFFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(4f);
        c.drawRoundRect(2, 2, getWidth()-2, getHeight()-2, r, r, edge);

        glass.setShader(null);
        edge.setShader(null);
    }
}
