package com.example.liquidglass;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GlassButton button = findViewById(R.id.glassButton);
        TextView status = findViewById(R.id.status);

        button.setOnPressStateChangedListener(pressed ->
                status.setText(pressed ? "Glass pressed" : "Ready"));
    }
}
