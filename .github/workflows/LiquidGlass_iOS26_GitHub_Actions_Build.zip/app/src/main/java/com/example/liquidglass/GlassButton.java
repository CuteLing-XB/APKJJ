package com.example.liquidglass;

import android.animation.*;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.TextView;

public class GlassButton extends TextView {
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float highlightX = .5f;
    private OnPressStateChangedListener listener;

    public interface OnPressStateChangedListener {
        void onChanged(boolean pressed);
    }

    public GlassButton(Context context) {
        super(context);
        setGravity(Gravity.CENTER);
        setClickable(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x66FFFFFF);
        bg.setCornerRadius(28);
        setBackground(bg);
        setElevation(10);

        setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    highlightX = e.getX() / Math.max(1f, getWidth());
                    animate().scaleX(.965f).scaleY(.965f).setDuration(90).start();
                    if (listener != null) listener.onChanged(true);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    highlightX = Math.max(0f, Math.min(1f, e.getX() / Math.max(1f, getWidth())));
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    animate().scaleX(1.0f).scaleY(1.0f)
                            .setDuration(260)
                            .setInterpolator(new OvershootInterpolator(1.6f))
                            .start();
                    if (listener != null) listener.onChanged(false);
                    invalidate();
                    return true;
            }
            return true;
        });
    }

    public void setOnPressStateChangedListener(OnPressStateChangedListener l) {
        listener = l;
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);

        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(1.4f);
        edge.setShader(new LinearGradient(
                highlightX * getWidth() - 100, 0,
                highlightX * getWidth() + 100, getHeight(),
                new int[]{0x00FFFFFF, 0xDFFFFFFF, 0x00FFFFFF},
                null, Shader.TileMode.CLAMP));
        c.drawRoundRect(1, 1, getWidth()-1, getHeight()-1, 28, 28, edge);

        Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
        gloss.setShader(new LinearGradient(
                0, 0, 0, getHeight() * .5f,
                new int[]{0x70FFFFFF, 0x12FFFFFF, 0x00FFFFFF},
                null, Shader.TileMode.CLAMP));
        c.drawRoundRect(3, 2, getWidth()-3, getHeight()*.55f, 25, 25, gloss);

        edge.setShader(null);
    }
}
