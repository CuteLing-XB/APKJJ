package com.example.liquidglass;

import android.content.Context;
import android.graphics.*;
import android.view.View;

public class LiquidGlassView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float phase;

    public LiquidGlassView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();

        paint.setShader(new LinearGradient(0, 0, w, h,
                Color.WHITE, Color.rgb(246,246,246), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, paint);

        paint.setShader(new RadialGradient(w * .22f, h * .20f, w * .48f,
                new int[]{0x32FFFFFF, 0x12DDE7FF, 0x00FFFFFF},
                null, Shader.TileMode.CLAMP));
        c.drawCircle(w * .22f, h * .20f, w * .48f, paint);

        phase += 0.006f;
        float x = (float)((Math.sin(phase) * .5 + .5) * (w * 1.35f) - w * .2f);

        paint.setShader(new LinearGradient(x, 0, x + w * .42f, h,
                new int[]{0x00FFFFFF, 0x28FFFFFF, 0x00FFFFFF},
                null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, paint);

        paint.setShader(null);
        postInvalidateOnAnimation();
    }
}
