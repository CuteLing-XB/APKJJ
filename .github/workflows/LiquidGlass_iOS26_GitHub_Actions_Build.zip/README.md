# LiquidGlass iOS 26 Style — GitHub Cloud Build

这是一个纯 UI 演示工程，使用 Android 原生 View 绘制 iOS 26 Liquid Glass 风格效果。

包含：
- 白色背景
- 半透明玻璃材质
- 高光边缘
- 光泽扫光
- 动态光带
- 阴影与层次
- 按住时缩放
- 松开后的柔性回弹
- 简化的折射/透镜视觉模拟

注意：这是 Android 上对 Liquid Glass 视觉语言的实现，不是 Apple 私有 UIGlassEffect 的移植。

## 云端构建

项目已经包含 GitHub Actions 工作流。

上传到 GitHub 后：
1. 打开仓库 Actions
2. 选择 `Build Android APK`
3. 点击 `Run workflow`
4. 等待构建完成
5. 打开构建结果
6. 在 Artifacts 下载 `LiquidGlass-debug-apk`

本工程不包含任何第三方解卡、验证码绕过或授权破解逻辑。
